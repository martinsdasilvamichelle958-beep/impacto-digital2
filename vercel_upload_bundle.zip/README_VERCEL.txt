
Vercel Upload Bundle — MARTINS • Impacto Digital
================================================

Arquivos que DEVEM estar na RAIZ do repositório GitHub:
- index.html
- style.css
- hero.mp4  (opcional; se pesado, otimize para 720p/1080p, 15–24fps, H.264)

Como usar:
1) No GitHub do seu projeto (ex.: impacto-digital2): Add file → Upload files
2) Arraste index.html e style.css (e hero.mp4, se couber)
3) Commit changes
4) No Vercel: New Project → escolha o repositório → Deploy
5) Abra a URL gerada (ex.: https://impacto-digital2.vercel.app)

Se aparecer 404:
- O repositório pode estar com apenas um .zip dentro (Vercel não lê ZIP). Extraia e envie os arquivos soltos.
- Garanta que exista um index.html na raiz do repositório.
