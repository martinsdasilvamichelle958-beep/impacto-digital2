MARTINS • Impacto Digital — Assets faltantes (para GitHub/Vercel)
=================================================================

Arquivos incluídos:
- style.css  → Folha de estilo do site
- (você precisa adicionar o vídeo) hero.mp4  → Vídeo do hero (não vai no ZIP)

Como usar no GitHub:
1) Entre no repositório impacto-digital → Add file → Upload files
2) Envie: style.css  (e seu vídeo, renomeado para hero.mp4)
3) Clique em Commit changes

Deploy no Vercel:
1) No painel do Vercel → New Project → selecione o repositório impacto-digital
2) Clique em Deploy e aguarde o link (ex.: https://impacto-digital.vercel.app)

Observações sobre o vídeo (hero.mp4):
- Tente manter o arquivo até ~20–30 MB para subir pela web no GitHub (limite prático).
- Se for maior, compacte o vídeo (1080p/720p, 15–24 fps, codec H.264).
- Alternativa: faça o deploy sem o vídeo e suba o hero.mp4 depois direto no Vercel (Storage) ou via Git LFS.